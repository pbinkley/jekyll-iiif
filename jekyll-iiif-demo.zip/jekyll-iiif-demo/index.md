---
layout: page
title: jekyll-iiif
iiif_image: Jheronimus_Bosch_011-1
---

This is a demo of [jekyll-iiif](https://github.com/pbinkley/jekyll-iiif)

## Manifest view

{% iiif_presentation narrenschiff %}

Source of page images: [Aff-ghebeelde narren speel-schuyt](https://archive.org/details/affghebeeldenarr00bran), 1610 (internet Archive).

## Image view

{% iiif %}

Image source: [Hieronymus Bosch, Ship of Fools](https://en.wikipedia.org/wiki/Ship_of_Fools_(painting)#/media/File:Jheronimus_Bosch_011.jpg) (Wikimedia)
